import {Suspense, lazy, useEffect, useMemo, useRef, useState} from 'react';
import {
  Activity, ArrowDownToLine, ArrowRight, AudioLines, BarChart3, BookOpen, Braces, BrainCircuit,
  Check, CheckCircle2, ChevronDown, Code2, Copy, ExternalLink, FileJson,
  FolderOpen, GitBranch, Heart, Info, Layers3, Link2, Loader2,
  Play, RotateCcw, Route, Search, ShieldCheck, Sparkles, Trash2, Upload,
} from 'lucide-react';
import {recipes} from '../lib/recipes/catalog';
import type {RecipeDefinition, RecipeId, RecipeResult} from '../lib/recipes/types';
import {cricketViewFromParams, patchCricketView, readCricketView, setCricketViewParams, type CricketView} from '../lib/recipes/models/cricket-view';
import {specs, scenes} from '../lib/motion/catalog';
import {appliedRecipes, appliedResults} from '../lib/motion/applied';
import {getSceneBasis} from '../lib/motion/basis';
import {PREFERENCE_KEY, validatePreferences, type Preferences, type Preference} from '../lib/preferences';
import {createZip, loadSourceBundle} from '../lib/zip';
import {MotionPlayer, useReducedMotion} from './Player';
import {CodeEditor, Dialog, VoteButtons} from './components';
import initialRecipe from './initial-recipe';
import {CricketStroke} from './CricketStroke';
import ExplorationAtlas from './labs/ExplorationAtlas';
const MusicLab = lazy(() => import('./labs/MusicLab'));
const OriginalsAtlas = lazy(() => import('./labs/OriginalsAtlas'));

const REPOSITORY = 'https://github.com/Runtheworldbetter/motion-atlas-studio';
const MOTION_CANVAS_PROJECT = 'https://github.com/motion-canvas/motion-canvas';
const ATLAS_DOCS = './docs/index.html';
const FILE_LIMIT = 128 * 1024;
const recipeIcons = {trace: GitBranch, waterfall: BarChart3, code: Braces, fourier: AudioLines, pathfinding: Route, cricket: Activity, 'post-training': BrainCircuit};
const recipeNames = {trace: 'Event trace', waterfall: 'Waterfall', code: 'Code diff', fourier: 'Harmonics', pathfinding: 'Pathfinder', cricket: 'Cricket', 'post-training': 'Post-training'};
const validPreferenceIds = new Set([...specs.map(s => s.id), ...recipes.map(r => `recipe:${r.id}`)]);
const sourceLoaders = import.meta.glob('../lib/{recipes,motion,cricket}/**/*.ts', {query: '?raw', import: 'default'});
type Draft = {input: string; secondary: string; exampleId: string; renderedInput: string; renderedSecondary: string};
type Inputs = {recipe: RecipeId; input: string; secondary?: string};

function requestedRecipe(): RecipeDefinition {
  const params = new URLSearchParams(location.search);
  return recipes.find(r => r.id === params.get('recipe')) ?? recipes.find(r => r.id === initialRecipe?.recipe) ?? recipes[0];
}
function startingDraft(recipe: RecipeDefinition): Draft {
  const params = new URLSearchParams(location.search);
  const example = (params.get('recipe') === recipe.id && recipe.examples.find(e => e.id === params.get('example'))) || recipe.examples[0];
  const custom = initialRecipe?.recipe === recipe.id && !params.has('example') ? initialRecipe : null;
  const baseInput = custom?.input ?? example.input;
  const input = recipe.id === 'cricket' && params.get('recipe') === 'cricket' ? patchCricketView(baseInput, cricketViewFromParams(params)) : baseInput;
  const secondary = custom?.secondary ?? example.secondary ?? '';
  return {input, secondary, exampleId: custom ? '' : example.id, renderedInput: input, renderedSecondary: secondary};
}
function download(content: BlobPart, filename: string, type = 'text/plain') {
  const url = URL.createObjectURL(new Blob([content], {type}));
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
function downloadSnapshot(canvas: HTMLCanvasElement, name: string) {
  canvas.toBlob(blob => {if (blob) download(blob, `motion-atlas-${name}.png`, 'image/png');}, 'image/png');
}
function sourcePath(id: string) {
  if (id === 'cricket-coaching') return 'lib/cricket/pose.ts';
  if (appliedRecipes[id]) return `lib/recipes/${appliedRecipes[id].id}.ts`;
  const category = specs.find(s => s.id === id)?.category;
  const group = category === 'Math & nature' ? 'math' : category === 'Systems & AI' ? 'systems' : category === 'Data stories' ? 'data' : 'craft';
  return `lib/motion/${group}.ts`;
}

export default function App() {
  const [recipeId, setRecipeId] = useState<RecipeId>(() => requestedRecipe().id);
  const [fullStroke, setFullStroke] = useState(() => {const example = new URLSearchParams(location.search).get('example'); return example === 'full-stroke' || (!example && initialRecipe?.recipe !== 'cricket');});
  const [drafts, setDrafts] = useState<Record<RecipeId, Draft>>(() => Object.fromEntries(recipes.map(r => [r.id, startingDraft(r)])) as Record<RecipeId, Draft>);
  const [results, setResults] = useState<Record<RecipeId, RecipeResult>>(() => Object.fromEntries(recipes.map(r => {const d = startingDraft(r); return [r.id, r.compile(d.input, d.secondary)];})) as Record<RecipeId, RecipeResult>);
  const [errors, setErrors] = useState<Partial<Record<RecipeId, string>>>({});
  const [activeTab, setActiveTab] = useState<'explain' | 'data' | 'source'>('explain');
  const [sourceText, setSourceText] = useState('');
  const [sourceModal, setSourceModal] = useState<{path: string; text: string} | null>(null);
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [selectedScene, setSelectedScene] = useState<string | null>(() => {
    const id = new URLSearchParams(location.search).get('scene'); return id && specs.some(s => s.id === id) ? id : null;
  });
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All examples');
  const [voteFilter, setVoteFilter] = useState('all');
  const [preferences, setPreferences] = useState<Preferences>(() => {
    try {return validatePreferences(JSON.parse(localStorage.getItem(PREFERENCE_KEY) ?? '{}'), validPreferenceIds);} catch {return {};}
  });
  const [storageAvailable, setStorageAvailable] = useState(true);
  const [preferencesOpen, setPreferencesOpen] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [galleryPlaying, setGalleryPlaying] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const reduced = useReducedMotion();
  const primaryUpload = useRef<HTMLInputElement>(null);
  const secondaryUpload = useRef<HTMLInputElement>(null);
  const preferencesUpload = useRef<HTMLInputElement>(null);
  const routeSearch = useRef(location.search);
  const draftsRef = useRef(drafts);
  draftsRef.current = drafts;
  const recipe = recipes.find(r => r.id === recipeId)!;
  const draft = drafts[recipeId];
  const result = results[recipeId];
  const dirty = draft.input !== draft.renderedInput || draft.secondary !== draft.renderedSecondary;
  const error = errors[recipeId];
  const embed = new URLSearchParams(location.search).get('embed') === '1';
  const activeExample = recipe.examples.find(e => e.id === draft.exampleId);
  const recipePreference = preferences[`recipe:${recipeId}`];
  const cricketView = recipeId === 'cricket' ? readCricketView(draft.input) ?? readCricketView(draft.renderedInput) : null;

  useEffect(() => {
    const sync = (event: StorageEvent) => {
      if (event.key !== PREFERENCE_KEY && event.key !== null) return;
      try {setPreferences(validatePreferences(JSON.parse(localStorage.getItem(PREFERENCE_KEY) ?? '{}'), validPreferenceIds));} catch {setStorageAvailable(false);}
    };
    try {localStorage.getItem(PREFERENCE_KEY);} catch {setStorageAvailable(false);}
    window.addEventListener('storage', sync);
    return () => window.removeEventListener('storage', sync);
  }, []);
  useEffect(() => {if (!notice) return; const timer = setTimeout(() => setNotice(''), 4200); return () => clearTimeout(timer);}, [notice]);
  useEffect(() => {if (reduced) setGalleryPlaying(false);}, [reduced]);
  useEffect(() => {
    const onPop = () => {
      // Fragment navigation can emit popstate too. Moving to a page section
      // must preserve the edited input and the frame held for inspection.
      if (location.search === routeSearch.current) return;
      routeSearch.current = location.search;
      const params = new URLSearchParams(location.search);
      const found = recipes.find(r => r.id === params.get('recipe')) ?? requestedRecipe();
      if (found) {
        setRecipeId(found.id);
        if (found.id === 'cricket') setFullStroke(!params.get('example') || params.get('example') === 'full-stroke');
        const ex = found.examples.find(e => e.id === params.get('example'));
        if (found.id === 'cricket' && ex) loadPreset(found, ex.id, false, cricketViewFromParams(params));
        else if (found.id === 'cricket') {
          // A route without a preset may belong to imported or edited input.
          // Restore only its view settings, keeping the current document.
          const saved = draftsRef.current.cricket;
          const view = readCricketView(saved.input), changes = cricketViewFromParams(params);
          if (view && Object.entries(changes).some(([key, value]) => view[key as keyof CricketView] !== value)) {
            renderDraft('cricket', {...saved, input: patchCricketView(saved.input, changes)});
          }
        }
        else if (ex) loadPreset(found, ex.id, false);
      }
      const id = params.get('scene'); setSelectedScene(id && specs.some(s => s.id === id) ? id : null);
    };
    window.addEventListener('popstate', onPop); return () => window.removeEventListener('popstate', onPop);
  }, []);
  useEffect(() => {
    if (activeTab !== 'source') return;
    let cancelled = false; setSourceText('Loading recipe source…');
    sourceLoaders[`../lib/recipes/${recipeId}.ts`]?.().then(text => {if (!cancelled) setSourceText(String(text));}).catch(() => {if (!cancelled) setSourceText('Open the source download for the complete recipe.');});
    return () => {cancelled = true;};
  }, [recipeId, activeTab]);

  function routeTo(id: RecipeId, exampleId: string, replace = false, input = drafts[id].input) {
    const url = new URL(location.href); url.search = ''; url.hash = ''; url.searchParams.set('recipe', id);
    if (exampleId) url.searchParams.set('example', exampleId);
    if (id === 'cricket') setCricketViewParams(url.searchParams, readCricketView(input));
    routeSearch.current = url.search;
    history[replace ? 'replaceState' : 'pushState']({}, '', url);
  }
  function selectRecipe(id: RecipeId) {setRecipeId(id); setActiveTab('explain'); if (id === 'cricket') setFullStroke(true); routeTo(id, id === 'cricket' ? 'full-stroke' : drafts[id].exampleId);}
  function renderDraft(id: RecipeId, next = drafts[id]) {
    const definition = recipes.find(r => r.id === id)!;
    try {
      const compiled = definition.compile(next.input, next.secondary);
      setResults(current => ({...current, [id]: compiled}));
      setDrafts(current => ({...current, [id]: {...next, renderedInput: next.input, renderedSecondary: next.secondary}}));
      setErrors(current => ({...current, [id]: ''}));
      return true;
    } catch (e) {setErrors(current => ({...current, [id]: e instanceof Error ? e.message : 'Please check this input.'})); return false;}
  }
  function loadPreset(definition: RecipeDefinition, exampleId: string, navigate = true, cricketOverrides?: Partial<CricketView>) {
    const example = definition.examples.find(e => e.id === exampleId) ?? definition.examples[0];
    if (definition.id === 'cricket') setFullStroke(false);
    const input = definition.id === 'cricket' ? patchCricketView(example.input, cricketOverrides ?? {handedness: readCricketView(drafts.cricket.input)?.handedness ?? 'left'}) : example.input;
    const next = {input, secondary: example.secondary ?? '', exampleId: example.id, renderedInput: input, renderedSecondary: example.secondary ?? ''};
    setRecipeId(definition.id); setDrafts(current => ({...current, [definition.id]: next})); renderDraft(definition.id, next);
    if (navigate) routeTo(definition.id, example.id, false, input);
  }
  function changeCricketView(changes: Partial<CricketView>) {
    try {
      const next = {...draft, input: patchCricketView(draft.input, changes)};
      if (renderDraft('cricket', next)) routeTo('cricket', next.exampleId, true, next.input);
    } catch (e) {setErrors(current => ({...current, cricket: e instanceof Error ? e.message : 'Please check this input.'}));}
  }
  function updateDraft(value: string, secondary = false) {
    setDrafts(current => ({...current, [recipeId]: {...current[recipeId], [secondary ? 'secondary' : 'input']: value}}));
    if (error) setErrors(current => ({...current, [recipeId]: ''}));
  }
  async function openInput(file: File | undefined, secondary = false) {
    if (!file) return;
    if (file.size > FILE_LIMIT) {setNotice('Please choose a file smaller than 128 KiB.'); return;}
    try {
      const text = await file.text();
      let imported: Inputs | null = null;
      try {
        const value = JSON.parse(text);
        if (value?.format === 'motion-atlas-input-v1') {
          if (!recipes.some(r => r.id === value.recipe) || typeof value.input !== 'string' || (value.secondary !== undefined && typeof value.secondary !== 'string')) throw new Error('Invalid input export.');
          imported = value;
        }
      } catch (e) {if (e instanceof Error && e.message === 'Invalid input export.') throw e;}
      if (imported) {
        if (imported.recipe === 'cricket') setFullStroke(false);
        const next = {...drafts[imported.recipe], input: imported.input, secondary: imported.secondary ?? '', exampleId: ''};
        setRecipeId(imported.recipe); setDrafts(current => ({...current, [imported!.recipe]: next})); renderDraft(imported.recipe, next); routeTo(imported.recipe, '', false, next.input);
      } else {
        const next = {...draft, [secondary ? 'secondary' : 'input']: text};
        setDrafts(current => ({...current, [recipeId]: next})); renderDraft(recipeId, next);
      }
      setNotice(`${file.name} opened locally.`);
    } catch (e) {setNotice(e instanceof Error ? e.message : 'The file could not be read.');}
  }
  function commitPreferences(update: (current: Preferences) => Preferences) {
    let current = preferences;
    try {current = validatePreferences(JSON.parse(localStorage.getItem(PREFERENCE_KEY) ?? '{}'), validPreferenceIds);} catch {setStorageAvailable(false);}
    const next = update(current);
    setPreferences(next);
    try {localStorage.setItem(PREFERENCE_KEY, JSON.stringify(next)); setStorageAvailable(true);} catch {setStorageAvailable(false);}
  }
  function setPreference(id: string, changes: Partial<Preference>) {commitPreferences(current => ({...current, [id]: {...(current[id] ?? {vote: 0, note: ''}), ...changes}}));}
  function linkFor(kind: 'recipe' | 'scene', id: string, embedded = false) {
    const url = new URL(location.origin + location.pathname); url.searchParams.set(kind, id);
    if (kind === 'recipe' && drafts[id as RecipeId].exampleId) url.searchParams.set('example', drafts[id as RecipeId].exampleId);
    if (kind === 'recipe' && id === 'cricket') setCricketViewParams(url.searchParams, readCricketView(drafts.cricket.input) ?? readCricketView(drafts.cricket.renderedInput));
    if (embedded) url.searchParams.set('embed', '1'); return url.href;
  }
  async function copy(text: string, message = 'Copied to clipboard.') {
    try {await navigator.clipboard.writeText(text); setNotice(message);} catch {setSourceModal({path: 'Copy this text', text});}
  }
  async function downloadProject() {
    try {
      recipe.compile(draft.input, draft.secondary); setBusy(true);
      const sourceURL = new URL('./source/bundle.json', location.href);
      const response = await fetch(sourceURL);
      if (!response.ok) throw new Error('The source download is temporarily unavailable.');
      const files = await loadSourceBundle(await response.json(), async name => {
        const part = await fetch(new URL(name, sourceURL));
        if (!part.ok) throw new Error('A source download part is temporarily unavailable.');
        return part.json();
      });
      files['src/initial-recipe.ts'] = `import type {RecipeId} from '../lib/recipes/types';\nconst initialRecipe: {recipe: RecipeId; input: string; secondary?: string} | null = ${JSON.stringify({recipe: recipeId, input: draft.input, secondary: draft.secondary}, null, 2)};\nexport default initialRecipe;\n`;
      files['YOUR-RECIPE.md'] = `# Your Motion Atlas recipe\n\nThis project opens with your edited ${recipeNames[recipeId]} inputs.\n\n1. Install Node.js 22.13 or newer.\n2. Run npm ci.\n3. Run npm run dev.\n4. Open the local address shown.\n\nYour input is saved in src/initial-recipe.ts.\n`;
      const bytes = createZip(files);
      download(bytes.buffer as ArrayBuffer, `motion-atlas-${recipeId}.zip`, 'application/zip');
      setNotice('Project downloaded with your edited inputs.');
    } catch (e) {setNotice(e instanceof Error ? e.message : 'Project download failed.');} finally {setBusy(false);}
  }
  function exportInput() {download(JSON.stringify({format: 'motion-atlas-input-v1', recipe: recipeId, input: draft.input, secondary: draft.secondary}, null, 2), `motion-atlas-${recipeId}-input.json`, 'application/json'); setNotice('Input downloaded. Open this file to restore it later.');}
  function openScene(id: string) {setSelectedScene(id); const url = new URL(location.href); url.search = ''; url.hash = ''; url.searchParams.set('scene', id); routeSearch.current = url.search; history.pushState({}, '', url);}
  function closeScene() {setSelectedScene(null); routeTo(recipeId, recipeId === 'cricket' && fullStroke ? 'full-stroke' : draft.exampleId, true);}
  async function viewSceneSource(id: string) {const path = sourcePath(id); const text = await sourceLoaders[`../${path}`]?.(); setSourceModal({path, text: String(text ?? 'Source unavailable.')});}
  const filtered = useMemo(() => specs.filter(s =>
    (category === 'All examples' || s.category === category) &&
    (voteFilter === 'all' || (voteFilter === 'liked' ? preferences[s.id]?.vote === 1 : voteFilter === 'disliked' ? preferences[s.id]?.vote === -1 : !preferences[s.id]?.vote)) &&
    `${s.title} ${s.description} ${s.tags.join(' ')}`.toLowerCase().includes(query.toLowerCase())), [category, query, voteFilter, preferences]);
  const selectedSpec = specs.find(s => s.id === selectedScene);
  const votedCount = Object.values(preferences).filter(p => p.vote !== 0).length;
  const likedCount = Object.values(preferences).filter(p => p.vote === 1).length;

  if (embed) {
    const id = selectedSpec?.id ?? recipeId;
    const model = selectedSpec ? appliedResults[selectedSpec.id] : result;
    const strokeEmbed = selectedSpec?.id === 'cricket-coaching' || (!selectedSpec && recipeId === 'cricket' && fullStroke);
    const embedTitle = strokeEmbed ? 'Complete straight drive' : selectedSpec?.title ?? result.title;
    const embedLink = strokeEmbed ? new URL('?recipe=cricket&example=full-stroke#studio', location.href).href : linkFor(selectedSpec ? 'scene' : 'recipe', id);
    return <main className="embed-shell">{strokeEmbed ? <CricketStroke/> : <MotionPlayer id={`embed-${id}`} factory={selectedSpec ? scenes[selectedSpec.id] : result.factory} title={selectedSpec?.title ?? result.title} autoplay={!reduced} loop={model?.loop} checkpoints={model?.checkpoints} frameStep={model?.frameStep}/>}<div className="embed-caption"><a href={embedLink} target="_blank" rel="noreferrer">{embedTitle} <ExternalLink size={13}/></a><span className="embed-credit"><a href={REPOSITORY} target="_blank" rel="noreferrer">Motion Atlas</a></span></div></main>;
  }

  return <>
    <a href="#studio" className="skip-link">Skip to editor</a>
    <header className="site-header atlas-with-explorations"><a className="brand" href={location.pathname} aria-label="Motion Atlas home"><span className="brand-mark">m</span><span>motion<span className="brand-serif">atlas</span><small>AN RTWB PROJECT</small></span></a><nav className="atlas-main-navigation" aria-label="Main navigation"><a href="#studio">Editor</a><a href="#collection">Collection <span>{specs.length}</span></a><a href="#explore">Explore</a><a href="#originals">Originals</a><a href="#music-lab">Music Lab</a><a href={ATLAS_DOCS}>Docs</a></nav><div className="header-actions"><button className="text-button saved-button" onClick={() => setPreferencesOpen(true)}><Heart size={16}/> Your picks {votedCount > 0 && <span className="count-badge">{votedCount}</span>}</button><a className="github-button" href={REPOSITORY} target="_blank" rel="noreferrer"><Code2 size={17}/><span>Atlas GitHub</span></a></div></header>

    <main>
      <section className="intro page-width"><div><p className="eyebrow"><span className="status-dot"/> MOTION ATLAS · EXAMPLES & EDITOR</p><h1>Animate your <em>data and code.</em></h1><p className="intro-copy">Choose an example, edit the input, and render the animation.</p></div><div className="intro-aside"><span className="local-badge"><ShieldCheck size={15}/> Runs in your browser</span><p>Your files are processed on your device.<br/>Download a project to keep editing.</p></div></section>

      <section className="upstream-credit page-width" aria-labelledby="atlas-source-heading">
        <div>
          <h2 id="atlas-source-heading">Make it yours with Motion Atlas.</h2>
          <p>Explore the source, reuse an explanation, or build your own. The editor, recipes, and coaching tools live together in one open source project.</p>
          <p className="upstream-thanks">Built by RTWB. Powered by Motion Canvas and browser-native graphics.</p>
        </div>
        <div className="upstream-links">
          <a href={REPOSITORY} target="_blank" rel="noreferrer"><Code2 size={18}/> Motion Atlas on GitHub</a>
          <a href={ATLAS_DOCS}><BookOpen size={18}/> Motion Atlas docs</a>
        </div>
      </section>

      <section id="studio" className="studio page-width" aria-label="Recipe editor">
        <div className="section-heading"><div className="section-kicker"><span>01</span> EDITOR</div></div>
        <div className="recipe-tabs" role="tablist" aria-label="Choose a recipe">{recipes.map(r => {const Icon = recipeIcons[r.id]; return <button key={r.id} id={`tab-${r.id}`} role="tab" aria-selected={recipeId === r.id} aria-controls="recipe-panel" tabIndex={recipeId === r.id ? 0 : -1} onClick={() => selectRecipe(r.id)} onKeyDown={e => {
          if (['ArrowRight', 'ArrowLeft', 'Home', 'End'].includes(e.key)) {e.preventDefault(); const current = recipes.findIndex(item => item.id === r.id); const index = e.key === 'Home' ? 0 : e.key === 'End' ? recipes.length - 1 : (current + (e.key === 'ArrowRight' ? 1 : -1) + recipes.length) % recipes.length; selectRecipe(recipes[index].id); document.getElementById(`tab-${recipes[index].id}`)?.focus();}
        }}><Icon size={18}/><span>{recipeNames[r.id]}</span>{recipeId === r.id && <span className="tab-dot"/>}</button>;})}</div>

        {recipeId === 'cricket' && <div className="cricket-editor-switch" role="group" aria-label="Cricket study"><button type="button" aria-pressed={fullStroke} onClick={() => {setFullStroke(true); routeTo('cricket', 'full-stroke');}}>Complete straight drive</button><button type="button" aria-pressed={!fullStroke} onClick={() => {setFullStroke(false); routeTo('cricket', draft.exampleId);}}>Custom keyframes</button><span>Pause, compare, inspect</span></div>}
        {recipeId === 'cricket' && fullStroke && <div id="recipe-panel" role="tabpanel" aria-labelledby="tab-cricket"><CricketStroke/></div>}
        {!(recipeId === 'cricket' && fullStroke) && <div id="recipe-panel" className="workspace" role="tabpanel" aria-labelledby={`tab-${recipeId}`}>

          <div className="input-panel">
            <div className="panel-heading"><span><Code2 size={15}/> EDIT THE INPUT</span><span className="format-badge">{recipe.inputFormat}</span></div>
            <div className="preset-select"><label htmlFor="preset">Start with an example</label><div><select id="preset" value={draft.exampleId} onChange={e => loadPreset(recipe, e.target.value)}>{!draft.exampleId && <option value="">Your imported example</option>}{recipe.examples.map(example => <option key={example.id} value={example.id}>{example.name}</option>)}</select><ChevronDown size={15}/></div><p>{activeExample?.description ?? 'Imported input.'}</p></div>
            {cricketView && <div className="cricket-view-controls">
              <span className="cricket-view-label">Batter</span>
              <div className="batting-mode" role="group" aria-label="Batting handedness">{(['left', 'right'] as const).map(hand => <button key={hand} type="button" aria-pressed={cricketView.handedness === hand} onClick={() => changeCricketView({handedness: hand})}>{hand === 'left' ? 'Left-handed' : 'Right-handed'}</button>)}</div>
              <label className="camera-flip"><input type="checkbox" checked={cricketView.mirror} onChange={e => changeCricketView({mirror: e.target.checked})}/> Flip camera view</label>
              <p>Hand and foot labels follow the batter. Flip the view to match your camera.</p>
            </div>}
            <div className="editor-label"><label>{recipe.inputLabel}</label><button className="text-button" onClick={() => primaryUpload.current?.click()}><FolderOpen size={14}/> Open file</button></div>
            <CodeEditor label={recipe.inputLabel} value={draft.input} onChange={value => updateDraft(value)} onRun={() => renderDraft(recipeId)} compact={!!recipe.secondaryLabel}/>
            {recipe.secondaryLabel && <><div className="editor-label"><label>{recipe.secondaryLabel}</label><button className="text-button" onClick={() => secondaryUpload.current?.click()}><FolderOpen size={14}/> Open file</button></div><CodeEditor label={recipe.secondaryLabel} value={draft.secondary} onChange={value => updateDraft(value, true)} onRun={() => renderDraft(recipeId)} compact/></>}
            <input ref={primaryUpload} className="visually-hidden" type="file" accept={`${recipe.accept},.json,application/json`} aria-label="Open primary input file" onChange={e => {openInput(e.target.files?.[0]); e.target.value = '';}}/>
            <input ref={secondaryUpload} className="visually-hidden" type="file" accept=".txt,.py,.js,.ts,.json" aria-label="Open after-code file" onChange={e => {openInput(e.target.files?.[0], true); e.target.value = '';}}/>
            {error && <div className="input-error" role="alert"><strong>Check the input</strong><p>{error}</p><span>The preview keeps the last valid version.</span></div>}
            <div className="editor-actions"><button className="primary-button" onClick={() => renderDraft(recipeId)}><Play size={15} fill="currentColor"/> Render changes <kbd>⌘ ↵</kbd></button><button className="icon-button" aria-label="Reset to selected example" title="Reset example" onClick={() => loadPreset(recipe, draft.exampleId)}><RotateCcw size={17}/></button><button className="icon-button" aria-label="Download editable input" title="Download input" onClick={exportInput}><ArrowDownToLine size={17}/></button></div>
            <div className="editor-status">{dirty ? <><span className="status-dot amber"/> Changes waiting to render</> : <><CheckCircle2 size={13}/> Preview up to date</>}<span>Download to save edits</span></div>
            <details className="input-help"><summary><Info size={14}/> Input format & limits</summary><p>{recipe.help}</p><p>Open a file up to 128 KiB or edit directly. Download your input to keep it after closing this tab.</p></details>
          </div>

          <div className="output-panel">
            <div className="panel-heading"><span><span className="status-dot"/> LIVE PREVIEW</span><a className="format-badge" href={MOTION_CANVAS_PROJECT} target="_blank" rel="noreferrer" aria-label="Motion Canvas animation engine on GitHub">MOTION CANVAS ↗</a></div>
            <MotionPlayer key={recipeId} id={`recipe-${recipeId}`} factory={result.factory} title={result.title} autoplay={!reduced} loop={result.loop} checkpoints={result.checkpoints} frameStep={result.frameStep} preservePlayback={recipeId === 'cricket'} onSnapshot={canvas => downloadSnapshot(canvas, recipeId)}/>
            <div className="preview-description"><div><h2>{result.title}</h2><p>{result.summary}</p></div><VoteButtons preference={recipePreference} title={recipeNames[recipeId]} onVote={vote => setPreference(`recipe:${recipeId}`, {vote})}/></div>
            <div className="result-tabs" role="tablist" aria-label="Recipe details"><button role="tab" aria-selected={activeTab === 'explain'} onClick={() => setActiveTab('explain')}><BookOpen size={14}/> How it works</button><button role="tab" aria-selected={activeTab === 'data'} onClick={() => setActiveTab('data')}><Layers3 size={14}/> Inspect values <span>{result.rows.length}</span></button><button role="tab" aria-selected={activeTab === 'source'} onClick={() => setActiveTab('source')}><Code2 size={14}/> Recipe source</button></div>
            <div className="result-details">
              {activeTab === 'explain' && <><p>{recipe.description}</p><div className="basis-note"><CheckCircle2 size={15}/><p>{recipe.basis}</p></div>{recipe.references && <ul className="recipe-references">{recipe.references.map(reference => <li key={reference.url}><a href={reference.url} target="_blank" rel="noreferrer">{reference.title} <ExternalLink size={12}/></a></li>)}</ul>}</>}
              {activeTab === 'data' && <div className="data-table-wrap"><table><thead><tr><th>Item</th><th>Value</th><th>Explanation</th></tr></thead><tbody>{result.rows.map((row, index) => <tr key={index}><th scope="row">{row.label}</th><td>{row.value}</td><td>{row.detail ?? ''}</td></tr>)}</tbody></table></div>}
              {activeTab === 'source' && <><div className="source-caption"><code>lib/recipes/{recipeId}.ts</code><button className="text-button" onClick={() => copy(sourceText)}><Copy size={13}/> Copy</button></div><pre className="source-code" tabIndex={0}>{sourceText}</pre><p className="small-note">The project download includes this code and your edited input.</p></>}
            </div>
            <div className="reuse-actions"><button className="secondary-button" onClick={downloadProject} disabled={busy}>{busy ? <Loader2 size={16} className="spinning"/> : <ArrowDownToLine size={16}/>} Download project</button><button className="text-button" onClick={() => setShareOpen(true)}><Link2 size={15}/> Share / embed</button><span className="reuse-note">Atlas: MIT · upstream licenses included</span></div>
          </div>
        </div>}
      </section>

      <section id="collection" className="collection page-width">
        <div className="section-heading"><div className="section-kicker"><span>02</span> EXAMPLES</div><button className="text-button" onClick={() => setGalleryPlaying(!galleryPlaying)}>{galleryPlaying ? 'Pause previews' : 'Animate previews'} <Sparkles size={15}/></button></div>
        <div className="collection-heading"><div><h2>Animation <em>examples.</em></h2><p>Browse coaching, AI, math, charts, and animation techniques. Use the arrows to save your preferences.</p></div><span className="collection-count">{specs.length} <small>EXAMPLES</small></span></div>
        <div className="category-filters" role="group" aria-label="Filter collection">{['All examples', 'Sports & coaching', 'Systems & AI', 'Math & nature', 'Data stories', 'Motion craft'].map(c => <button key={c} aria-pressed={category === c} onClick={() => setCategory(c)}>{c}<span>{c === 'All examples' ? specs.length : specs.filter(scene => scene.category === c).length}</span></button>)}</div>
        <div className="collection-toolbar"><label className="search-field"><Search size={17}/><input aria-label="Search examples" placeholder="Search examples…" value={query} onChange={e => setQuery(e.target.value)}/></label><div className="filter-right"><span>{filtered.length} {filtered.length === 1 ? 'example' : 'examples'}</span><select aria-label="Filter by your votes" value={voteFilter} onChange={e => setVoteFilter(e.target.value)}><option value="all">All votes</option><option value="liked">Upvoted</option><option value="disliked">Downvoted</option><option value="unrated">Unrated</option></select></div></div>
        <div className="gallery-grid">{filtered.map((spec, i) => <article key={spec.id} className="gallery-card"><button className="gallery-open" onClick={() => openScene(spec.id)} aria-label={`Open ${spec.title}`}><div className="card-preview">{spec.id === 'cricket-coaching' ? <CricketStroke compact autoplay={galleryPlaying && !reduced}/> : <MotionPlayer id={`card-${spec.id}`} factory={scenes[spec.id]} title={spec.title} compact autoplay={galleryPlaying && !reduced} posterTime={2.5}/>}<span className="card-number">{String(specs.findIndex(s => s.id === spec.id) + 1).padStart(2, '0')}</span><span className="open-indicator"><ArrowRight size={18}/></span></div></button><div className="card-body"><p className="card-category">{spec.category}</p><h3><button onClick={() => openScene(spec.id)}>{spec.title}</button></h3><p>{spec.description}</p><div className="card-footer"><span className="basis-pill">{getSceneBasis(spec.id).label}</span><VoteButtons title={spec.title} preference={preferences[spec.id]} onVote={vote => setPreference(spec.id, {vote})}/></div></div></article>)}</div>
        {!filtered.length && <div className="empty-state"><Search size={28}/><h3>No matching examples.</h3><p>Try a different search or clear your filters.</p><button className="secondary-button" onClick={() => {setQuery(''); setCategory('All examples'); setVoteFilter('all');}}>Clear filters</button></div>}
        <div className="collection-footnote"><ShieldCheck size={15}/><span>Your votes and notes are saved in this browser. Export them to use on another device.</span><button className="text-button" onClick={() => setPreferencesOpen(true)}>Review your picks <ArrowRight size={14}/></button></div>
      </section>

      <ExplorationAtlas/>
      <Suspense fallback={<section id="originals" className="page-width lab-loading">Opening Originals…</section>}><OriginalsAtlas/></Suspense>
      <Suspense fallback={<section id="music-lab" className="page-width lab-loading">Opening Music Lab…</section>}><MusicLab/></Suspense>

      <section id="guide" className="guide page-width"><div className="section-kicker"><span>03</span> QUICK START</div><h2>Using the <em>editor.</em></h2><div className="guide-grid"><article><span className="guide-number">01</span><h3>Edit an example</h3><p>Choose a recipe and edit its text, or open a local file.</p></article><article><span className="guide-number">02</span><h3>Preview the animation</h3><p>Click Render changes. Pause or scrub the timeline, and use Inspect values to check the numbers.</p></article><article><span className="guide-number">03</span><h3>Save or share</h3><p>Download your input, a runnable project, or a PNG. Share links and embeds open the selected preset.</p></article></div><div className="open-source-banner"><div><p className="eyebrow">SOURCE CODE</p><h3>Run the editor locally</h3><p>Install Node.js 22.13 or newer, download the source, and run:</p></div><div><code>npm ci<br/>npm run dev</code><div className="banner-links"><a className="secondary-button" href="./motion-atlas-source.zip" download><ArrowDownToLine size={15}/> Download source</a><a className="text-button" href={REPOSITORY} target="_blank" rel="noreferrer">GitHub <ExternalLink size={14}/></a></div></div></div></section>
    </main>

    <footer className="site-footer page-width"><a className="brand footer-brand" href="https://runtheworldbetter.com" target="_blank" rel="noreferrer">RTWB <ArrowRight size={16}/></a><div><a href={REPOSITORY} target="_blank" rel="noreferrer">Motion Atlas on GitHub</a><a href={ATLAS_DOCS}>Atlas docs</a><a href="./third-party-notices.txt" target="_blank" rel="noreferrer">Licenses & credits</a><button className="text-button" onClick={() => setPreferencesOpen(true)}>Your local data</button></div></footer>

    {selectedSpec && <Dialog title={selectedSpec.title} wide onClose={closeScene}><p className="eyebrow">{selectedSpec.category}</p><h2 className="dialog-title">{selectedSpec.title}</h2>{selectedSpec.id === 'cricket-coaching' ? <CricketStroke/> : <MotionPlayer id={`view-${selectedSpec.id}`} factory={scenes[selectedSpec.id]} title={selectedSpec.title} autoplay={!reduced} loop={appliedResults[selectedSpec.id]?.loop} checkpoints={appliedResults[selectedSpec.id]?.checkpoints} frameStep={appliedResults[selectedSpec.id]?.frameStep} onSnapshot={canvas => downloadSnapshot(canvas, selectedSpec.id)}/>}<div className="scene-description"><p>{selectedSpec.description}</p><VoteButtons title={selectedSpec.title} preference={preferences[selectedSpec.id]} onVote={vote => setPreference(selectedSpec.id, {vote})}/></div><div className="basis-note"><Info size={17}/><p><strong>{getSceneBasis(selectedSpec.id).label}.</strong> {getSceneBasis(selectedSpec.id).detail}</p></div><p className="scene-technique">{selectedSpec.technique}</p><label className="note-label" htmlFor="scene-note">Your notes <span>Saved in this browser</span></label><textarea id="scene-note" className="note-input" placeholder="Add a note…" maxLength={1200} value={preferences[selectedSpec.id]?.note ?? ''} onChange={e => setPreference(selectedSpec.id, {note: e.target.value})}/><div className="dialog-actions">{appliedRecipes[selectedSpec.id] && <button className="primary-button" onClick={() => {setSelectedScene(null); selectRecipe(appliedRecipes[selectedSpec.id].id); document.getElementById('studio')?.scrollIntoView({behavior: reduced ? 'auto' : 'smooth'});}}>Edit this example <ArrowRight size={15}/></button>}<button className="secondary-button" onClick={() => viewSceneSource(selectedSpec.id)}><Code2 size={15}/> View source</button><button className="text-button" onClick={() => copy(linkFor('scene', selectedSpec.id), 'Scene link copied.')}><Link2 size={15}/> Copy link</button><button className="text-button" onClick={() => copy(`<iframe src="${linkFor('scene', selectedSpec.id, true)}" title="${selectedSpec.title.replaceAll('"', '&quot;')}" style="width:100%;aspect-ratio:16/10;border:0" loading="lazy" allowfullscreen></iframe>`, 'Embed code copied.')}><Code2 size={15}/> Copy embed</button></div></Dialog>}

    {shareOpen && <Dialog title="Share this recipe" onClose={() => setShareOpen(false)}><h2 className="dialog-title">Share this example</h2><p>These links open <strong>{activeExample?.name ?? recipe.examples[0].name}</strong>. To share your edits, use Download project.</p><label className="share-label">Recipe link</label><div className="copy-field"><input readOnly value={linkFor('recipe', recipeId)} aria-label="Recipe link"/><button className="icon-button" aria-label="Copy recipe link" onClick={() => copy(linkFor('recipe', recipeId), 'Preset link copied.')}><Copy size={17}/></button></div><label className="share-label">Embed in a page</label><textarea className="embed-code" readOnly aria-label="Embed code" value={`<iframe src="${linkFor('recipe', recipeId, true)}" title="Motion Atlas ${recipeNames[recipeId]}" style="width:100%;aspect-ratio:16/10;border:0" loading="lazy" allowfullscreen></iframe>`}/><div className="dialog-actions"><button className="secondary-button" onClick={() => copy(`<iframe src="${linkFor('recipe', recipeId, true)}" title="Motion Atlas ${recipeNames[recipeId]}" style="width:100%;aspect-ratio:16/10;border:0" loading="lazy" allowfullscreen></iframe>`)}>Copy embed</button><button className="text-button" onClick={downloadProject}>Download your project <ArrowDownToLine size={15}/></button></div></Dialog>}

    {sourceModal && <Dialog title="Source code" wide onClose={() => setSourceModal(null)}><p className="eyebrow">SOURCE CODE</p><h2 className="dialog-title source-title">{sourceModal.path}</h2><pre className="modal-source" tabIndex={0}>{sourceModal.text}</pre><div className="dialog-actions"><button className="secondary-button" onClick={() => copy(sourceModal.text)}><Copy size={15}/> Copy source</button><a className="text-button" href="./motion-atlas-source.zip" download>Download complete source <ArrowDownToLine size={15}/></a></div></Dialog>}

    {preferencesOpen && <Dialog title="Your local preferences" onClose={() => {setPreferencesOpen(false); setConfirmClear(false);}}><h2 className="dialog-title">Your picks</h2><p>Review your votes and notes. {storageAvailable ? 'Everything here is saved in this browser.' : 'Browser storage is unavailable; export to keep your choices.'}</p><div className="preference-summary"><div><strong>{likedCount}</strong><span>UPVOTED</span></div><div><strong>{votedCount - likedCount}</strong><span>DOWNVOTED</span></div><div><strong>{Object.values(preferences).filter(p => p.note).length}</strong><span>NOTES</span></div></div><div className="preference-list">{Object.entries(preferences).filter(([,p]) => p.vote !== 0 || p.note).map(([id,p]) => {const spec = specs.find(s => s.id === id); const r = recipes.find(item => `recipe:${item.id}` === id); return <div key={id}><div><strong>{spec?.title ?? r?.title ?? id}</strong>{p.note && <p>{p.note}</p>}</div><VoteButtons title={spec?.title ?? r?.title ?? id} preference={p} onVote={vote => setPreference(id, {vote})}/></div>;})}{!Object.values(preferences).some(p => p.vote !== 0 || p.note) && <p className="empty-picks">Use the arrows on an example to save your preference.</p>}</div><div className="dialog-actions"><button className="secondary-button" onClick={() => download(JSON.stringify({format: 'motion-atlas-preferences-v2', exportedAt: new Date().toISOString(), preferences}, null, 2), 'motion-atlas-preferences.json', 'application/json')}><ArrowDownToLine size={15}/> Export preferences</button><button className="text-button" onClick={() => preferencesUpload.current?.click()}><Upload size={15}/> Import</button></div><input ref={preferencesUpload} type="file" className="visually-hidden" accept=".json" aria-label="Import preferences" onChange={async e => {const file = e.target.files?.[0]; e.target.value = ''; if (!file) return; if (file.size > FILE_LIMIT) {setNotice('Preference file must be smaller than 128 KiB.'); return;} try {const value = JSON.parse(await file.text()); const imported = validatePreferences(value.preferences, validPreferenceIds); commitPreferences(current => ({...current, ...imported})); setNotice('Preferences imported into this browser.');} catch (err) {setNotice(err instanceof Error ? err.message : 'Invalid preferences file.');}}}/><div className="clear-data">{confirmClear ? <><span>Clear all votes and notes on this device?</span><button className="danger-button" onClick={() => {commitPreferences(() => ({})); setConfirmClear(false); setNotice('Local preferences cleared.');}}>Clear everything</button><button className="text-button" onClick={() => setConfirmClear(false)}>Cancel</button></> : <button className="text-button" onClick={() => setConfirmClear(true)}><Trash2 size={14}/> Clear local preferences</button>}</div></Dialog>}

    {notice && <div className="toast" role="status"><Check size={16}/>{notice}</div>}
    {!storageAvailable && <div className="storage-warning" role="status">Preferences are temporary. Export them to keep a copy.</div>}
  </>;
}
